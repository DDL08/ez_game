<?php

$uploadDir = __DIR__ . "/upload/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir);
}

$fileTmpPath = $_FILES["file"]["tmp_name"];
$fileName = $_FILES["file"]["name"];
$fileSize = $_FILES["file"]["size"];
$fileType = $_FILES["file"]["type"];
$fileError = $_FILES["file"]["error"];


$fileContent = file_get_contents($fileTmpPath);


if (preg_match('/<\?php|shell_exec|eval|base64_decode|system|passthru|popen|proc_open/i', $fileContent)) {
    echo "非法的文件内容";
    exit;
}

$allowedExts = ['jpg', 'jpeg', 'png', 'gif','php'];
$ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

if (!in_array($ext, $allowedExts)) {
    echo "非法的文件扩展名";
    exit;
}

if ((($fileType == "image/gif")
    || ($fileType == "image/jpeg")
    || ($fileType == "image/jpg")
    || ($fileType == "image/pjpeg")
    || ($fileType == "image/x-png")
    || ($fileType == "image/png"))
    && ($fileSize < 204800)) {

    if ($fileError > 0) {
        echo "错误：: " . $fileError . "<br>";
    } else {
        move_uploaded_file($fileTmpPath, $uploadDir . $fileName);
        echo "文件上传成功";
    }

} else {
    echo "非法的文件格式";
}
?>
