#!/bin/bash

if [ "$1" != "--dir" ] || [ -z "$2" ]; then
    echo "Usage: $0 --dir /path/to/dir"
    exit 1
fi

WATCH_DIR="$2"
INTERVAL=0.5

echo "
    _____________
   < FileMonitor >
    -------------
    By DDL (Bash Version - Auto Delete .php Files)
"

declare -A prev_files
declare -A curr_files

scan_files() {
    local dir="$1"
    local -n map=$2
    while IFS= read -r file; do
        [[ -f "$file" && "$file" == *.php ]] && map["$file"]="$(stat -c %s "$file")"
    done < <(find "$dir" -type f -name "*.php")
}

compare_files() {
    for file in "${!curr_files[@]}"; do
        if [[ -z "${prev_files[$file]}" ]]; then
            echo "[+] Detected new PHP file: $file"
            rm -f "$file" && echo "[x] Deleted: $file"
        fi
    done

    for file in "${!prev_files[@]}"; do
        if [[ -z "${curr_files[$file]}" ]]; then
            echo "[-] PHP file deleted: $file"
        fi
    done

    for file in "${!curr_files[@]}"; do
        if [[ -n "${prev_files[$file]}" ]] && [[ "${curr_files[$file]}" != "${prev_files[$file]}" ]]; then
            echo "[~] PHP file modified: $file"
        fi
    done
}

# 初次扫描
scan_files "$WATCH_DIR" prev_files

while true; do
    sleep "$INTERVAL"

    unset curr_files
    declare -A curr_files
    scan_files "$WATCH_DIR" curr_files

    compare_files

    # 更新快照
    unset prev_files
    declare -A prev_files
    for key in "${!curr_files[@]}"; do
        prev_files["$key"]="${curr_files[$key]}"
    done
done

