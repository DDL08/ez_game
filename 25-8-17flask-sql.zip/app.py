from flask import Flask, render_template, request, redirect, url_for, session, send_file
import random, string, io, time
from PIL import Image, ImageDraw, ImageFont
from base64 import b64decode
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
import sqlite3

app = Flask(__name__)
app.secret_key = '114514114514'
#DB_PATH = 'database.db'
DB_PATH = r"C:\Users\LEGION\Desktop\新建文件夹\02\src\python-code\垃圾箱\出题\1\database.db"

# 初始化数据库（第一次运行时用）
def init_db(db_path=DB_PATH, schema_path=r'C:\Users\LEGION\Desktop\新建文件夹\02\src\python-code\垃圾箱\出题\1\db.sqlite.sql'):
    conn = sqlite3.connect(db_path)
    with open(schema_path, 'r', encoding='utf-8') as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()

# 获取数据库连接，支持用列名访问结果
def get_db_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# 加载私钥（路径请根据实际调整）
with open(r"C:\Users\LEGION\Desktop\新建文件夹\02\src\python-code\垃圾箱\出题\1\private_key.pem", "rb") as f:
    private_key = serialization.load_pem_private_key(f.read(), password=None)

# 生成随机验证码文本
def generate_captcha_text(length=4):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

# 生成验证码图片
def generate_captcha_image(text):
    image = Image.new('RGB', (100, 40), color=(255, 255, 255))
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    for i, char in enumerate(text):
        draw.text((10 + i * 20, 10), char, font=font, fill=(0, 0, 0))
    return image

# RSA 解密密码
def rsa_decrypt(encrypted_base64):
    encrypted_data = b64decode(encrypted_base64)
    decrypted = private_key.decrypt(encrypted_data, padding.PKCS1v15())
    return decrypted.decode('utf-8')

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login2.html')

    username = "admin"
    encrypted_pwd = request.form.get('password_encrypted')
    try:
        pwd = rsa_decrypt(encrypted_pwd)
    except Exception:
        return "密码解密失败"

    captcha_input = request.form.get('captcha', '').strip().upper()
    if not captcha_input:
        return "请填写验证码"

    try:
        conn = get_db_conn()
        cursor = conn.cursor()

        # 查询最新未使用的验证码
        sql = "SELECT * FROM captcha_codes WHERE used = 0 ORDER BY id DESC LIMIT 1"
        cursor.execute(sql)
        captcha_row = cursor.fetchone()

        if not captcha_row:
            cursor.close()
            conn.close()
            return "验证码无效或已过期，请刷新验证码"

        if captcha_row['code'] != captcha_input:
            cursor.close()
            conn.close()
            return "验证码错误"

        captcha_id = captcha_row['id']

        # 标记验证码为已使用
        cursor.execute("UPDATE captcha_codes SET used = 1 WHERE id = ?", (captcha_id,))
        conn.commit()

        # 验证用户名和密码（参数化查询防注入）
        # sql = "SELECT * FROM admin_user2 WHERE username2 = ? AND password2 = ?"
        # cursor.execute(sql, (username, pwd))
        sql = f"SELECT * FROM admin_user2 WHERE username2 = '{username}' AND password2 = '{pwd}'"
        cursor.execute(sql) 
        user = cursor.fetchone()

        cursor.close()
        conn.close()

        if user:
            return "登录成功，欢迎admin！\n但是这啥也没有，你看看漏洞在哪里？"
        else:
            return "用户名或密码错误"

    except Exception as e:
        return f"数据库连接失败：{str(e)}"

@app.route('/captcha')
def captcha():
    captcha_text = generate_captcha_text().upper()

    try:
        conn = get_db_conn()
        cursor = conn.cursor()
        sql = "INSERT INTO captcha_codes (code, used) VALUES (?, 0)"
        cursor.execute(sql, (captcha_text,))
        captcha_id = cursor.lastrowid
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        return f"数据库错误: {e}", 500

    session['latest_captcha_id'] = captcha_id
    session['captcha'] = {
        'text': captcha_text,
        'id': captcha_id,
        'timestamp': time.time()
    }

    image = generate_captcha_image(captcha_text)
    buffer = io.BytesIO()
    image.save(buffer, 'PNG')
    buffer.seek(0)
    return send_file(buffer, mimetype='image/png')

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
