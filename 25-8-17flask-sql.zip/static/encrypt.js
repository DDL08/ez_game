// encrypt.js
function encrypt(pwd){
var key3 = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs9uXBWkw5j/51MsXmog2
3kzQl+CYU6XTly2eJf+0l4QMYwRzNaDvLrGLmxKe+3Ck3zUPEftveRFPLKGZJHVN
Hfqphj1G94tbhIFe6p/MWNahR9aSDW4VUILhNglt9wCisGjTBkwGG8xB6ch3ggtf
46cEEfVoWd9Q522TSZdMsHWWfYOJXg5YZU9ZpOt26Jb5aD4IpD4FpW6MrRUgiGRX
s3AQvLusQW4TC4SvHnhygLk4mkNJi+COUElKd7khgF/u1xxB9rhX8/dpOhlAXdhT
MxwnJrqE4bbmCQxGoWm6N3Lxq6CQDK0OHAkz/UaMnd6zKsxGcvFS/FrOTxTdIEV1
sQIDAQAB
-----END PUBLIC KEY-----
`;

    var encrypt = new JSEncrypt();
    encrypt.setPublicKey(key3);
    var encrypted = encrypt.encrypt(pwd);
    return encrypted;
}
