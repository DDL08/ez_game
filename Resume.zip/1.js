const express = require('express');
const puppeteer = require('puppeteer');
const sanitizeHtml = require('sanitize-html');

const app = express();
app.use(express.urlencoded({ extended: false }));

const flag = process.env['GZCTF_FLAG'] ?? 'flag{test_flag}';
const PORT = process.env?.BOT_PORT || 80;

const xssStorage = [];

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Resume Submission</title>
      <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-100 flex items-center justify-center min-h-screen">
      <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Submit Your Resume</h2>
        <p class="text-gray-600 mb-4 text-center">Enter your resume details below (text only).</p>
        <form method="POST" action="/" class="space-y-4">
          <div>
            <label for="content" class="block text-sm font-medium text-gray-700">Resume Content</label>
            <textarea id="content" name="content" rows="6" class="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="Enter your resume details here..."></textarea>
          </div>
          <button type="submit" class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition">Submit Resume</button>
        </form>
        <p class="mt-4 text-center">
          <a href="/view" class="text-blue-600 hover:underline">View Submitted Resumes</a>
        </p>
      </div>
    </body>
    </html>
  `);
});

app.post('/', (req, res) => {
  let { content } = req.body;
  //  content = content.slice(0, 150);
  if (content) {

    content = sanitizeHtml(content, {
      allowedTags: ['div', 'span', 'b', 'i', 'u', 'a', 'img'],
      allowedAttributes: {
        div: ['data-content'],
        a: ['href'],
        img: ['src'],
        span: ['style'],
      },
      allowedSchemes: ['http', 'https'],
      disallowedTagsMode: 'discard',
      transformTags: {
        '*': (tagName, attribs) => {
          const filteredAttribs = {};
          for (const key in attribs) {
            if (!key.startsWith('on') && !attribs[key].match(/(fetch|alert|eval|javascript:)/i)) {
              filteredAttribs[key] = attribs[key];
            }
          }
          return { tagName, attribs: filteredAttribs };
        }
      }
    });
    const content2=Buffer.from(content).toString("ascii");
    xssStorage.push(content2);
    console.log(`[+] Stored resume content: ${content}`);
  }
  res.redirect('/view');
});
app.get('/view', (req, res) => {
  let html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Submitted Resumes</title>
      <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-100 flex items-center justify-center min-h-screen">
      <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Submitted Resumes</h2>
        <p class="text-gray-600 mb-4 text-center">Below are the submitted resumes.</p>
        <ul class="space-y-4">
  `;
  xssStorage.forEach((content, index) => {
    html += `<li class="p-4 border border-gray-200 rounded-md">${content}</li>`;
  });
  html += `
        </ul>
        <div class="mt-6 flex justify-center space-x-4">
          <a href="/" class="text-blue-600 hover:underline">Submit Another Resume</a>
          <form method="POST" action="/report">
            <input type="hidden" name="url" value="http://localhost:80/view">
            <button type="submit" class="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition">Send to approver</button>
          </form>
        </div>
      </div>
    </body>
    </html>
  `;
  res.send(html);
});

app.post('/report', async (req, res) => {
  const { url } = req.body;

  if (!url || (!url.startsWith('http://localhost') && !url.startsWith('http://localhost'))) {
    return res.status(400).send('Invalid URL');
  }

  try {
    console.log(`[+] Visiting: ${url}`);
    const browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    const cookieDomain = url.startsWith('http://localhost') ? 'localhost' : 'challenge';
    console.log(`[+] Setting cookie for domain: ${cookieDomain}`);
    await page.setCookie({ name: 'flag', value: flag, domain: cookieDomain });//
    page.on('console', msg => console.log('PAGE LOG:', msg.text()));
    page.on('pageerror', error => console.error('PAGE ERROR:', error));
    page.on('requestfailed', request => console.error('REQUEST FAILED:', request.url(), request.failure()));
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 10000 });
    await page.waitForNetworkIdle({ timeout: 10000 });
    await browser.close();
    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bot Visited</title>
        <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body class="bg-gray-100 flex items-center justify-center min-h-screen">
        <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl text-center">
          <h2 class="text-2xl font-bold text-gray-800 mb-4">Success!</h2>
          <p class="text-gray-600 mb-4">The review bot has visited the URL: ${url}</p>
          <a href="/" class="text-blue-600 hover:underline">Back to Resume Submission</a>
        </div>
      </body>
      </html>
    `);
  } catch (err) {
    console.error(`[!] Error visiting URL: ${url}`, err);
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body class="bg-gray-100 flex items-center justify-center min-h-screen">
        <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl text-center">
          <h2 class="text-2xl font-bold text-red-600 mb-4">Error</h2>
          <p class="text-gray-600 mb-4">Bot error visiting URL: ${err.message}</p>
          <a href="/" class="text-blue-600 hover:underline">Back to Resume Submission</a>
        </div>
      </body>
      </html>
    `);
  }
});

app.listen(PORT, () => {
  console.log(`XSS bot and resume submission server running at port ${PORT}`);
});
