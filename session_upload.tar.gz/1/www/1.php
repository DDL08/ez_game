<?php
show_source(__FILE__);

if (isset($_GET["file"])) {
    $file = $_GET["file"];

    // 禁止包含flag
    if (preg_match("/flag/i", $file)) {
        die("no flag !!!");
    }

    // 禁止伪协议
    $blacklist_protocols = ['data://', 'filter://', 'php://', 'zip://', 'glob://', 'phar://'];

    foreach ($blacklist_protocols as $proto) {
        if (stripos($file, $proto) !== false) {
            die("No allowed protocol in file path!");
        }
    }

    include $file;
}

