<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        /* 整体页面样式 */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        /* 登录框样式 */
       .login-box {
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* 错误提示信息样式 */
       .error-msg {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="login-box">
        <h2>Login</h2>
        <form method="POST" autocomplete="off">
            <label>Username: 
                <input name="username" placeholder="Username" value="admin">
            </label><br>
            <label>Password: 
                <input name="password" type="password" placeholder="Password">
            </label><br>
            <button type="submit">Login</button>
        </form>
        <?php if (isset($msg)):?>
            <p class="error-msg"><?php echo $msg;?></p>
        <?php endif;?>
    </div>
</body>

</html>

<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username'])? $_POST['username'] : '';
    $pass = isset($_POST['password'])? $_POST['password'] : '';

    if ($username === 'admin') {
        $_SESSION['user'] = $username;
        header("Location: 1.php");
        exit;
    } else {
        $msg = "Login failed!";
    }
}
?>
