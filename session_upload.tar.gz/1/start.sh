#!/bin/sh
sleep 1

sed -i "s/flag{test}/$GZCTF_FLAG/" /F11aagg111164864.txt
export GZCTF_FLAG="" 

apache2-foreground
