import socket
import threading
import io
from contextlib import redirect_stdout
import unicodedata
import sys
import os
import Crypto
import builtins
sys.modules.pop('_posixsubprocess', None)


blacklist_modules = ["_posixsubprocess", "shutil"]

_real_import = builtins.__import__

def safe_import(name, *args, **kwargs):
    if name in blacklist_modules:
        raise ImportError(f"Forbidden import: {name}")
    return _real_import(name, *args, **kwargs)

builtins.__import__ = safe_import



def handle_client(client_socket):
    user_globals = {"__builtins__": __builtins__}
    try:
        client_socket.send(b"--- AAASanBox ---\n")
        client_socket.send(b"--- Type 'EXIT' to quit, 'RUN' to execute multi-line code ---\n")
        
        while True:
            client_socket.send(b">>> ")
            code_buffer = []
            while True:
                data = client_socket.recv(5120).decode('utf-8').strip()
                if data.upper() == 'RUN':
                    break
                if data.upper() == 'EXIT':
                    client_socket.send(b"Goodbye!\n")
                    return
                code_buffer.append(data)
                client_socket.send(b"... ")

            user_input = "\n".join(code_buffer)
            user_input=unicodedata.normalize('NFKC', user_input)
            blacklist = []
            if any(word in user_input for word in blacklist):
                client_socket.send(b"Danger! Blacklist word detected.\n")
                continue

            output_capture = io.StringIO()
            try:
                with redirect_stdout(output_capture):
                    exec(user_input, user_globals)
                
                result = output_capture.getvalue()
                if result:
                    client_socket.send(result.encode())
                else:
                    client_socket.send(b"(Success with no output)\n")
            except Exception as e:
                client_socket.send(f"Runtime Error: {str(e)}\n".encode())
                
    except Exception as e:
        print(f"Connection error: {e}")
    finally:
        client_socket.close()

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", 5000))
    server.listen(10)
    print("[*] NC Sandbox Server started on port 10001")
    while True:
        client, addr = server.accept()
        threading.Thread(target=handle_client, args=(client,)).start()

if __name__ == "__main__":
    try:
        1+1
    except:
        pass
    #import subprocess
    del os.popen
    del os.system
    sys.addaudithook(Crypto.audit_checker)

    main() 
