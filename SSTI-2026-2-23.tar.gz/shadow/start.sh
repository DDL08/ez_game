#!/bin/sh

sed -i "s/flag{t-e-s-t}/$GZCTF_FLAG/" /app/flag.txt

# 设置环境变量
export GZCTF_FLAG=""

chown root:root /app/flag.txt
chmod 600 /app/flag.txt

# 等待 1 秒
sleep 1

exec su ctf -c "python /app/1.py"
