audit_functions = {
        #"compile",
        "importlib.util",
        "import",
        "os.system",
        "subprocess.Popen",
        "subprocess.run",
        "subprocess.call",
        "subprocess.check_call",
        "subprocess.check_output",
        "_posixsubprocess.fork_exec",
        "os.spawn",
        "os.spawnlp",
        "os.spawnv",
        "os.spawnve",
        "os.exec",
        "os.execve",
        "os.execvp",
        "os.execvpe",
        "os.fork",
        "shutil.run",
        "shutil.copyfile",
        "shutil.move",
        "sys._getframe", 
        "sys._current_frames", 
        "gc.get_objects"
}

def audit_checker(event, args):
    if event in audit_functions:
        #raise RuntimeError(event)
        if event == "import":
            module_name = args[0]
            safe_modules = ["os","subprocess", "_posixsubprocess", "shutil"]
            if module_name not in safe_modules:
                return
            else:
                raise RuntimeError(f"Forbidden import: {module_name}")
        else:
            raise RuntimeError("Forbidden!")


