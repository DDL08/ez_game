const express = require('express');
const puppeteer = require('puppeteer');
const sanitizeHtml = require('sanitize-html');

const app = express();
app.use(express.urlencoded({ extended: false }));

const flag = process.env['GZCTF_FLAG'] ?? 'flag{test_flag}';
const PORT = process.env?.BOT_PORT || 3000;

const xssStorage = [];
const Reg = /\b(script|iframe|object|embed|math|form|input|textarea|button)\b/gi;
//const CSP_HEAD_REGEX =/<html\b[^>]*>[\s\S]*?<head\b[^>]*>\s*<meta http-equiv="Content-Security-Policy" content="default-src 'none'">/i;只能空白不能注释
const CSP_HEAD_REGEX =/<html\b[^>]*>[\s\S]*?<head\b[^>]*>[\s\S]*?<meta http-equiv="Content-Security-Policy" content="default-src 'none'">/i;
const FORBIDDEN_TAG_REGEX = /<(?!\!--)[a-zA-Z]/;
const EVENTS = ["onsearch","onappinstalled","onbeforeinstallprompt","onbeforexrselect","onabort","onbeforeinput","onbeforematch","onbeforetoggle","onblur","oncancel","oncanplay","oncanplaythrough","onchange","onclick","onclose","oncontentvisibilityautostatechange","oncontextlost","oncontextmenu","oncontextrestored","oncuechange","ondblclick","ondrag","ondragend","ondragenter","ondragleave","ondragover","ondragstart","ondrop","ondurationchange","onemptied","onended","onerror","onfocus","onformdata","oninput","oninvalid","onkeydown","onkeypress","onkeyup","onload","onloadeddata","onloadedmetadata","onloadstart","onmousedown","onmouseenter","onmouseleave","onmousemove","onmouseout","onmouseover","onmouseup","onmousewheel","onpause","onplay","onplaying","onprogress","onratechange","onreset","onresize","onscroll","onsecuritypolicyviolation","onseeked","onseeking","onselect","onslotchange","onstalled","onsubmit","onsuspend","ontimeupdate","ontoggle","onvolumechange","onwaiting","onwebkitanimationend","onwebkitanimationiteration","onwebkitanimationstart","onwebkittransitionend","onwheel","onauxclick","ongotpointercapture","onlostpointercapture","onpointerdown","onpointermove","onpointerrawupdate","onpointerup","onpointercancel","onpointerover","onpointerout","onpointerenter","onpointerleave","onselectstart","onselectionchange","onanimationend","onanimationiteration","onanimationstart","ontransitionrun","ontransitionstart","ontransitionend","ontransitioncancel","onafterprint","onbeforeprint","onbeforeunload","onhashchange","onlanguagechange","onmessage","onmessageerror","onoffline","ononline","onpagehide","onpageshow","onpopstate","onrejectionhandled","onstorage","onunhandledrejection","onunload","onpageswap","onpagereveal","onoverscroll","onscrollend","onscrollsnapchange","onscrollsnapchanging","ontimezonechange"];
const EVENT_SELECTOR = EVENTS.map(e=>`*[${e}]`).join(',');

let browsera;
function check(html) {
    return CSP_HEAD_REGEX.test(html);
}
function check2(html) {
  const CSP_META =
    `<meta http-equiv="Content-Security-Policy" content="default-src 'none'">`;

  const htmlMatch = html.match(/<html\b[^>]*>/i);
  if (!htmlMatch) return false;

  const afterHtml = html.slice(htmlMatch.index + htmlMatch[0].length);

  
  const firstTagAfterHtml = afterHtml.match(/<\s*\/?\s*([a-zA-Z0-9:-]+)/);
  if (!firstTagAfterHtml || firstTagAfterHtml[1].toLowerCase() !== 'head') {
    return false;
  }

  const headMatch = afterHtml.match(/<head\b[^>]*>/i);
  if (!headMatch) return false;

  const afterHead = afterHtml.slice(headMatch.index + headMatch[0].length);


  const metaIndex = afterHead.indexOf(CSP_META);
  if (metaIndex === -1) return false;


  const betweenHeadAndMeta = afterHead.slice(0, metaIndex);


  const FORBIDDEN_TAG_REGEX = /<(?!\!--)/;

  if (FORBIDDEN_TAG_REGEX.test(betweenHeadAndMeta)) {
    return false;
  }


  const afterFirstMeta = afterHead.slice(metaIndex + CSP_META.length);
  const untilHeadClose = afterFirstMeta.split(/<\/head\s*>/i)[0];

  const illegalTagAfterMeta = /<(?!meta\b|\/meta\b)[a-zA-Z]/i;
  if (illegalTagAfterMeta.test(untilHeadClose)) {
    return false;
  }

  return true;
}


async function check3(url) {
    let valid = false;
    let context;
        try{        browsera = await puppeteer.launch({
            headless: true,
            pipe: true,
            args: [
                "--no-sandbox",
                "--disable-setuid-sandbox",
            ],
            dumpio: true
        });}catch(e){console.error(e);}
    try {
        context = await browsera.createBrowserContext();
        const page = await context.newPage();
        page.setDefaultTimeout(2000);
        await page.setJavaScriptEnabled(false);
        await page.setRequestInterception(true);
        let reqCount = 0;
        page.on('request', interceptedRequest => {
            reqCount++;
            if (interceptedRequest.isInterceptResolutionHandled()) return;
            if (reqCount > 1) {
                interceptedRequest.abort();
            }
            else
                interceptedRequest.continue();
        });
        await page.goto(url, { timeout: 3000, waitUntil: 'domcontentloaded' });
        valid = await page.evaluate((s) => {
            return document.querySelector('head').firstElementChild.outerHTML === `<meta http-equiv="Content-Security-Policy" content="default-src 'none'">`&& document.querySelector('script, noscript, frame, iframe, object, embed') === null && document.querySelector(s) === null
        }, EVENT_SELECTOR) && reqCount === 1;
    }
    catch (e) {
        console.error(e);
    }
    finally {
        if (context) await context.close();
    }
    return valid;
}
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resume Submission 2.0</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
  <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl">
    <!-- 更新标题为2.0版本 -->
    <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Submit Your Resume (2.0)</h2>
    <!-- 修改提示文本，说明支持HTML格式 -->
    <p class="text-gray-600 mb-4 text-center">Enter your resume details below (HTML format supported).</p>
    <form method="POST" action="/" class="space-y-4">
      <div>
        <!-- 更新标签文本，明确说明HTML格式 -->
        <label for="content" class="block text-sm font-medium text-gray-700">Resume Content (HTML Format)</label>
        <!-- 优化文本域提示，给出HTML示例 -->
        <textarea id="content" name="content" rows="10" class="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" placeholder="Example:
<h1>John Doe</h1>
<h2>Software Engineer</h2>
<p>Email: john@example.com</p>
<ul>
  <li>Skill 1: HTML/CSS/JS</li>
  <li>Skill 2: Python/Java</li>
</ul>
">></textarea>
      </div>
      <!-- 保持提交按钮不变 -->
      <button type="submit" class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition">Submit Resume</button>
    </form>
    <!-- 保持查看简历链接不变 -->
    <p class="mt-4 text-center">
      <a href="/view" class="text-blue-600 hover:underline">View Submitted Resumes</a>
    </p>
  </div>
</body>
</html>
  `);
});

app.post('/', async(req, res) => {
  let  content  = req.body.content;
    if (!content)
        return res.status(400).send('No content.');
    content = content.trim();
    if (!content.startsWith('<html>'))
        return res.status(400).send('Invalid content.')
    if (!content.includes('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'">'))
        return res.status(400).send('No CSP.');
  content = content.replace(Reg, '');
  if (content) {
  if (! check(content)) {
    return res.status(400).send('Failed validation.-1');
    }
  if (! check2(content)) {
    return res.status(400).send('Failed validation.-2');
    }
  // if (! (await check3(content)) ) {
  //   return res.status(400).send('Failed validation.-2');
  //   }
    xssStorage.push(content);
    console.log(`[+] Stored resume content: ${content}`);
  }
  res.redirect('/view');
});





app.get('/view', (req, res) => {
  let html ;
  xssStorage.forEach((content, index) => {
    html = `${content}`;
  });

  res.send(html);
});



app.post('/report', async (req, res) => {
  const { url } = req.body;

  if (!url || (!url.startsWith('http://localhost') && !url.startsWith('http://localhost'))) {
    return res.status(400).send('Invalid URL');
  }

  try {
    console.log(`[+] Visiting: ${url}`);
    const browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox','--js-flags=--noexpose_wasm,--jitless'],
      headless: true,
      dumpio: false,
      pipe: true

    });

    const page = await browser.newPage();
    const cookieDomain = url.startsWith('http://localhost') ? 'localhost' : 'challenge';
    console.log(`[+] Setting cookie for domain: ${cookieDomain}`);
    await page.setCookie({ name: 'flag', value: flag, domain: cookieDomain });//
    page.on('console', msg => console.log('PAGE LOG:', msg.text()));
    page.on('pageerror', error => console.error('PAGE ERROR:', error));
    page.on('requestfailed', request => console.error('REQUEST FAILED:', request.url(), request.failure()));
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 10000 });
    await page.waitForNetworkIdle({ timeout: 10000 });
    await browser.close();
    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bot Visited</title>
        <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body class="bg-gray-100 flex items-center justify-center min-h-screen">
        <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl text-center">
          <h2 class="text-2xl font-bold text-gray-800 mb-4">Success!</h2>
          <p class="text-gray-600 mb-4">The review bot has visited the URL: ${url}</p>
          <a href="/" class="text-blue-600 hover:underline">Back to Resume Submission</a>
        </div>
      </body>
      </html>
    `);
  } catch (err) {
    console.error(`[!] Error visiting URL: ${url}`, err);
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <script src="https://cdn.tailwindcss.com"></script>
      </head>
      <body class="bg-gray-100 flex items-center justify-center min-h-screen">
        <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl text-center">
          <h2 class="text-2xl font-bold text-red-600 mb-4">Error</h2>
          <p class="text-gray-600 mb-4">Bot error visiting URL: ${err.message}</p>
          <a href="/" class="text-blue-600 hover:underline">Back to Resume Submission</a>
        </div>
      </body>
      </html>
    `);
  }
});

app.listen(PORT, () => {
  console.log(`XSS bot and resume submission server running at port ${PORT}`);
});

