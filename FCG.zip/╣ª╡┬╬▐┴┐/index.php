<!DOCTYPE html>
<html lang="zh">
<head>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/crypto-js.min.js"></script> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>敲木鱼游戏</title>
    <style>
        body {
            margin: 0;
            overflow: hidden;
            background: url('3.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        #muyu {
            position: absolute;
            cursor: pointer;
        }
        #score {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            font-size: 24px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div id="score">（功德至少要过万才能给你flag哦）当前功德: 0</div>
    <img id="muyu" src="4.jpg" alt="木鱼" width="100">

    <script>
        let score = 0; // 全局变量，用于存储得分

        // 更新得分的函数
        function updateScore(value) {
            score += value;
            document.getElementById('score').innerText = "（功德至少要过万才能给你flag哦）当前功德: " + score; // 更新得分显示
            console.log("当前得分: " + score);

//这还用看吗，想法让score>100000
            if (score > 100000) { 
let octalString = "126 124 112 107 143 62 122 110 126 155 164 131 115 124 150 172 124 62 167 62 145 152 106 155 122 106 122 157 144 126 147 61 121 153 164 113 115 110 126 110 115 127 65 113 121 126 106 115 116 124 150 123 122 60 61 106 143 127 111 167 116 124 112 164 115 63 131 60 144 124 106 166 132 151 71 167 143 155 106 113 124 124 150 166 142 167 75 75";      let text = o1(octalString); let base64Decoded = atob(text);     let decrypted = d2(base64Decoded, '1');console.log("Decrypted flag: " + decrypted);} } function o1(octalString) { let octalNumbers = octalString.split(' ');let text = '';for (let i = 0; i < octalNumbers.length; i++) {text += String.fromCharCode(parseInt(octalNumbers[i], 8)); }return text; }function d2(encrypted, key) {let bytes = CryptoJS.AES.decrypt(encrypted, key, { iv: '' });return bytes.toString(CryptoJS.enc.Utf8); }

//echo flag;
        // 随机位置生成
        function moveMuyu() {
            const munyuf = document.getElementById("muyu");
            const { innerWidth: width, innerHeight: height } = window;
            const x = Math.random() * (width - 100); // 100是图片宽度
            const y = Math.random() * (height - 100); // 100是图片高度

            munyuf.style.left = `${x}px`;
            munyuf.style.top = `${y}px`;
        }

        // 点击木鱼的事件
        document.getElementById("muyu").addEventListener("click", function () {
            updateScore(1); // 每次点击得1分
            moveMuyu(); // 移动木鱼
        });

        // 初始化游戏
        function initGame() {
            moveMuyu(); // 第一次移动木鱼
        }

        // 启动游戏
        initGame();
    </script>
</body>
</html>