<?php
// db.php

$servername = "127.0.0.1"; // 或者你的数据库服务器
$username = "root"; // 数据库用户名
$password = "root"; // 数据库密码
$dbname = "ctf"; // 数据库名称

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 在数据库连接后，设置连接字符集为 utf8mb4
mysqli_set_charset($conn, 'utf8mb4');

// 检查连接
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

