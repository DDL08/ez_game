<?php
include('db.php');
header('Content-Type: application/json');
$input_data = file_get_contents("php://input");

$data = json_decode($input_data, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["error" => "Invalid JSON data"]);
    exit();
}


$encryptedData = isset($data['encryptedData']) ? $data['encryptedData'] : null;
$iv = isset($data['iv']) ? $data['iv'] : null;


if ($encryptedData === null || $iv === null) {
    echo json_encode(["error" => "Encrypted data or IV is required"]);
    exit();
}
$secretKey = "1234567890123456";
$encryptedData = base64_decode($encryptedData);
$iv = base64_decode($iv);

$decryptedData = openssl_decrypt(
    $encryptedData,
    'aes-128-cbc',
    $secretKey,
    OPENSSL_RAW_DATA,
    $iv
);

if ($decryptedData === false) {
    echo json_encode(["error" => "Failed to decrypt the data"]);
    exit();
}

$decodedData = json_decode($decryptedData, true);
if (!isset($decodedData['category'])) {
    echo json_encode(["error" => "Invalid or missing category"]);
    exit();
}

$category =$decodedData['category']; 


$sql = "SELECT text FROM data WHERE id = '$category'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(["category" => $category, "content" => $row['text']]);
} else {
    echo json_encode(["error" => "No content found for this category"]);
}

$conn->close();
?>

